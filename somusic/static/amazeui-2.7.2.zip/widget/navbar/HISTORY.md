# Navbar 更新记录
---

## v2.0.2 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.1 (2014.11.12)

- `CHANGED` 网格、等分网格 Class 修改。

## v2.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## v1.2.0 (2014.08.28)

- `IMPROVED` 重写交互；
- `IMPROVED` 使用 Amaze UI Share 插件，移除百度分享；
- `CHANGED` 删除图标位置选项，只提供图标在上方的样式；
- `IMPROVED` 主题细节调整。


### 2014-03-7

 * [tag:navbar] 修改数据接口 icon 修改为 icon (使用icon font) 与 customIcon(使用<img src="上传的图片">)

### 2014-02-26

 * [tag:navbar] #464 增加 navbar 链接数较多时自动生成一个弹出菜单 功能

### 2014-02-11 新增
