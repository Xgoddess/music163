# blank
---

This blank widget allow developers to build their own widget.

## Structure

```javascript
// Blank. Write your own data structure according to the HTML of your widget.
```
