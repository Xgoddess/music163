# blank 更新记录
---

## v2.0.0 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。