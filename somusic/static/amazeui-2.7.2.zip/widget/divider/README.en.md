# Divider
---

This widget is used to create beautiful dividers.

## Usage

### Copy and Paste

- Copy the codes in examples, and paste it to the `<body>` of the Amaze UI HTML template([Download](/getting-started));

### Using Handlebars

The Handlebars partial name of this widget is `divider`. See more details in [Accordion](/widgets/accordion).

### Allmobilize WebIDE

This widget don't need data-binding.

## Structure

```javascript
{
  "id": "",

  "className": "",

  "theme": "default"
}
```