# 2 Columns 更新日志
---

## v2.0.1 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.0 (2014.11.12)

- `CHANGED` 网格、等分网格 Class 修改。

##  ver 1.0.0 （2014.02.14）

`NEW` 两列等分网格系统