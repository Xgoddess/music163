# Footer 更细记录
---

## v3.1.2 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v3.1.1 (2014.12.16)

- `CHANGED` add `addToHS` option, diable `addToHS` default

## v3.1.0 (2014.12.08)

- `CHANGED` Remove powered by。

## v3.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## ver 2.2.0 (2014.10.20)

- `NEW` 增加禁用【添加到桌面图标】接口。

## ver 2.1.1 (2014.04.11)

- `FIXED` 修复与 navbar 共存时窗口无法关闭的 bug

## ver 2.1.0

### 2014-02-17 取消站点类型，增加技术支持公司和网址

- `NEW` [#459](https://github.com/allmobilize/issues/issues/459) Add to HomeScreen

## ver 2.0.0

### 2013-12-25 增加“自动获取语言”模式

### 2013-12-17 新增

详情：新增 footer 模块，本模块中包含 switch_mode 模块；另外，可添加一些其他信息，例如：网站页尾信息、版权信息、备案信息等内容，这些内容可通过 p 标签进行添加。
