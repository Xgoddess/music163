# MeChat 更新记录
---
## v2.0.1 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## ver 1.0.0 (2014.08.08)

- `NEW` 新增。
