# 3 Columns
---

3 Columns

## Data Interface

```javascript
{
    "id": "",
    "className": ""
}
```