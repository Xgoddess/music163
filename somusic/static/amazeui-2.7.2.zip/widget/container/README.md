# Container
---

容器模块。

## API

```javascript
{
  "id": "",
  "className": "",
  "theme": ""
}
```
