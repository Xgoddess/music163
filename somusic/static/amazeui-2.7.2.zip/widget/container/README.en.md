# Container
---

Container widget.


## API

```javascript
{
  "id": "",
  "className": "",
  "theme": ""
}
```