# Header 更新记录
---

## ver 2.0.0 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## ver 1.1.1 (2015.01.08)

- `CHANGED` 删除 options 选项；

## ver 1.1.0 (2014.10.11)

- `NEW` 增加固定位置样式；

## ver 1.0.0 (2014.08.08)

- `NEW` 新增页头组件；
