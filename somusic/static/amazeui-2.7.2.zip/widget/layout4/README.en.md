# 4 Columns
---

4 Columns

## Data Interface

```javascript
{
    "id": "",
    "className": ""
}
```