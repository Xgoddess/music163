---
id: about
title: 关于我们
titleEn: About
next: about/wantu.html
---

# 关于我们
---

Amaze UI 是一个轻量级、 Mobile first 的前端框架， 由 Amaze UI 小组基于开源社区流行前端框架编写。

Amaze UI 小组目前有两位成员，我们崇尚开放、自由，欢迎大家参与到 Amaze UI 开发、维护中来。
