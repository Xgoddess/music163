# Share
---

Share plugin.

<button class="am-btn am-btn-primary" data-am-toggle="share">Share to <i class="am-icon-share-alt"></i></button>

